<?php

return [
    'name' => 'Gallery'
];
