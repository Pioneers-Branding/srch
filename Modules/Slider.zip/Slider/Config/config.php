<?php

return [
    'name' => 'Slider',
];
